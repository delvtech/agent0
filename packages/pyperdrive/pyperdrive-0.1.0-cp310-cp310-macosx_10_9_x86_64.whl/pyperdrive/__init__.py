"""Python module wrapping the Rust implementation of HyperdriveMath"""
# pylint: disable=import-self
from .pyperdrive import *  # type: ignore
